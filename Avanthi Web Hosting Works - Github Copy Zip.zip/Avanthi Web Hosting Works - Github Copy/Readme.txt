Thanks for downloading this template!

Template Name: Sailor
Template URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
